//
//  DetailViewController.swift
//  ResponsibleCollectionViewWithRandomFiveImageSelection
//
//  Created by The iOS App Series on 6/25/19.
//  Copyright © 2019 The iOS App Series. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var img4: UIImageView!
    @IBOutlet weak var img5: UIImageView!
    
    var str1 = ""
    var str2 = ""
    var str3 = ""
    var str4 = ""
    var str5 = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        img1.image = UIImage(named: str1)
        img2.image = UIImage(named: str2)
        img3.image = UIImage(named: str3)
        img4.image = UIImage(named: str4)
        img5.image = UIImage(named: str5)
    }
    
}
