//
//  ItemCell.swift
//  GridViewExampleApp
//
//  Created by The iOS App Series on 6/25/19.
//  Copyright © 2019 The iOS App Series. All rights reserved.
//

import UIKit

class ItemCell: UICollectionViewCell {
    @IBOutlet weak var imgBG: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
