//
//  ViewController.swift
//  ResponsibleCollectionViewWithRandomFiveImageSelection
//
//  Created by The iOS App Series on 6/25/19.
//  Copyright © 2019 The iOS App Series. All rights reserved.
//
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    let dataArray = ["1", "2", "3", "4", "5", "6", "7","8","9","10"]
    
    var estimateWidth = 160.0
    var cellMarginSize = 16.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set Delegates
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
        // Register cells
        self.collectionView.register(UINib(nibName: "ItemCell", bundle: nil), forCellWithReuseIdentifier: "ItemCell")
        
        // SetupGrid view
        self.setupGridView()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        self.setupGridView()
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
    
    
    func setupGridView() {
        let flow = collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
        flow.minimumInteritemSpacing = CGFloat(self.cellMarginSize)
        flow.minimumLineSpacing = CGFloat(self.cellMarginSize)
    }
}

extension ViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.dataArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ItemCell", for: indexPath) as! ItemCell
        cell.imgBG.image = UIImage(named: dataArray[indexPath.row])
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let detailVC:DetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "detailVC") as! DetailViewController
        
        if indexPath.row == 0
        {
            detailVC.str1 = dataArray[indexPath.row]
            detailVC.str2 = dataArray[indexPath.index(after: indexPath.row)]
            
            detailVC.str3 = dataArray[indexPath.index(after: indexPath.row + 1)]
            detailVC.str4 = dataArray[indexPath.index(after: indexPath.row + 2)]
            detailVC.str5 = dataArray[indexPath.index(after: indexPath.row + 3)]
        }
        else if indexPath.row == 1
        {
            detailVC.str1 = dataArray[indexPath.row]
            detailVC.str2 = dataArray[indexPath.index(before: indexPath.row)]
            
            detailVC.str3 = dataArray[indexPath.index(after: indexPath.row)]
            detailVC.str4 = dataArray[indexPath.index(after: indexPath.row + 1)]
            detailVC.str5 = dataArray[indexPath.index(after: indexPath.row + 2)]
            
        }
        else if indexPath.row == 8
        {
            detailVC.str1 = dataArray[indexPath.row]
            detailVC.str2 = dataArray[indexPath.index(after: indexPath.row)]
            
            detailVC.str3 = dataArray[indexPath.index(before: indexPath.row)]
            detailVC.str4 = dataArray[indexPath.index(before: indexPath.row - 1)]
            detailVC.str5 = dataArray[indexPath.index(before: indexPath.row - 2)]
        }
        else if indexPath.row == 9
        {
            detailVC.str1 = dataArray[indexPath.row]
            detailVC.str2 = dataArray[indexPath.index(before: indexPath.row)]
            
            detailVC.str3 = dataArray[indexPath.index(before: indexPath.row - 1)]
            detailVC.str4 = dataArray[indexPath.index(before: indexPath.row - 2)]
            detailVC.str5 = dataArray[indexPath.index(before: indexPath.row - 3)]
        }
        else
        {
            detailVC.str1 = dataArray[indexPath.row]
            detailVC.str2 = dataArray[indexPath.index(before: indexPath.row)]
            
            detailVC.str3 = dataArray[indexPath.index(before: indexPath.row - 1)]
            detailVC.str4 = dataArray[indexPath.index(after: indexPath.row)]
            detailVC.str5 = dataArray[indexPath.index(after: indexPath.row + 1)]
        }
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = self.calculateWith()
        return CGSize(width: width, height: width)
    }
    
    func calculateWith() -> CGFloat {
        let estimatedWidth = CGFloat(estimateWidth)
        let cellCount = floor(CGFloat(self.view.frame.size.width / estimatedWidth))
        
        let margin = CGFloat(cellMarginSize * 2)
        let width = (self.view.frame.size.width - CGFloat(cellMarginSize) * (cellCount - 1) - margin) / cellCount
        
        return width
    }
}


